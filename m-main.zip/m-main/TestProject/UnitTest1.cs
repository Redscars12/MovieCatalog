using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Movie_Catalog.Data;
using Movie_Catalog.Data.Models;
using Movie_Catalog.Services;
using Xunit;

namespace MovieCatalog.Tests
{
    public class MovieServiceTests
    {
        private async Task<AppDbContext> GetInMemoryDbContextAsync()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDb")
            .Options;

            var context = new AppDbContext(options);

            // Seed some data
            context.Movies.Add(new Movie { Title = "Inception" });
            context.Movies.Add(new Movie { Title = "The Matrix" });
            await context.SaveChangesAsync();

            return context;
        }

        [Fact]
        public async Task GetAllMoviesAsync_ReturnsAllMovies()
        {
            // Arrange
            var context = await GetInMemoryDbContextAsync();
            var service = new MovieService(context);

            // Act
            var result = await service.GetAllMoviesAsync();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
            Assert.Contains(result, m => m.Title == "Inception");
            Assert.Contains(result, m => m.Title == "The Matrix");
        }
    }
}
