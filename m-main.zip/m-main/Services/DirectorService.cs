﻿using Microsoft.EntityFrameworkCore;
using Movie_Catalog.Data;
using Movie_Catalog.Data.Models;
using Movie_Catalog.Services.Interfaces;
using System.Threading.Tasks;

namespace Movie_Catalog.Services
{
    public class DirectorService : IDirectorService
    {
        private readonly MovieCatalogContext _context;

        public DirectorService(MovieCatalogContext context)
        {
            _context = context;
        }

        public async Task<ICollection<Director>> GetAllDirectorsAsync()
        {
            return await _context.Directors.ToListAsync();
        }

        public async Task<Director> GetDirectorByIdAsync(int id)
        {
            return await _context.Directors.FindAsync(id);
        }

        // Method to get a director by name
        public async Task<Director> GetDirectorByNameAsync(string name)
        {
            // Use ToLower() for case-insensitive comparison
            return await _context.Directors
                                 .FirstOrDefaultAsync(d => d.Name.ToLower() == name.ToLower());
        }


        // Method to add a new director
        public async Task AddDirectorAsync(string name)
        {
            var director = new Director { Name = name };
            _context.Directors.Add(director);
            await _context.SaveChangesAsync();
        }

        public async Task EditAsync(int id, string name)
        {
            var director = await _context.Directors.FindAsync(id);
            if (director != null)
            {
                director.Name = name;
                _context.Directors.Update(director);
                await _context.SaveChangesAsync();
            }
        }
    }
}



