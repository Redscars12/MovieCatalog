﻿using Microsoft.EntityFrameworkCore;
using Movie_Catalog.Data;
using Movie_Catalog.Data.Models;
using Movie_Catalog.Services.Interfaces;

namespace Movie_Catalog.Services
{
    public class RatingService : IRatingService
    {
        private readonly MovieCatalogContext _context;

        public RatingService(MovieCatalogContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Rating>> GetAllRatingsAsync()
        {
            return await _context.Ratings
                .Include(r => r.Movie)
                .ToListAsync();
        }

        public async Task<Rating?> GetRatingByIdAsync(int id)
        {
            return await _context.Ratings
                .Include(r => r.Movie)
                .FirstOrDefaultAsync(r => r.Id == id);
        }

        public async Task<IEnumerable<Rating>> GetRatingsByMovieIdAsync(int movieId)
        {
            return await _context.Ratings
                .Where(r => r.MovieId == movieId)
                .ToListAsync();
        }

        // NEW: Get movie by title
        public async Task<Movie?> GetMovieByTitleAsync(string title)
        {
            return await _context.Movies
                .Include(m => m.Ratings)
                .FirstOrDefaultAsync(m => m.Title.Equals(title, StringComparison.OrdinalIgnoreCase));
        }

        // UPDATED: Add rating by movie title
        public async Task AddRatingAsync(string title, double ratingValue)
        {
            var movie = await _context.Movies
                .Include(m => m.Ratings)
                .FirstOrDefaultAsync(m => m.Title == title);

            if (movie == null)
            {
                throw new KeyNotFoundException($"Movie with title '{title}' was not found.");
            }

            var rating = new Rating
            {
                MovieId = movie.Id,
                RatingValue = ratingValue
            };

            _context.Ratings.Add(rating);
            await _context.SaveChangesAsync();

            // Refresh average rating
            movie = await _context.Movies
                .Include(m => m.Ratings)
                .FirstOrDefaultAsync(m => m.Id == movie.Id);

            movie.Rating = movie.Ratings.Average(r => r.RatingValue);
            await _context.SaveChangesAsync();
        }


        public async Task DeleteRatingAsync(int id)
        {
            var rating = await _context.Ratings.FindAsync(id);

            if (rating == null)
            {
                throw new KeyNotFoundException($"Rating with ID {id} was not found.");
            }

            int? movieId = rating.MovieId;

            _context.Ratings.Remove(rating);
            await _context.SaveChangesAsync();

            // Update movie's average rating after deletion
            if (movieId.HasValue)
            {
                var movie = await _context.Movies
                    .Include(m => m.Ratings)
                    .FirstOrDefaultAsync(m => m.Id == movieId.Value);

                if (movie != null)
                {
                    movie.Rating = movie.Ratings.Any()
                        ? movie.Ratings.Average(r => r.RatingValue)
                        : 0;

                    await _context.SaveChangesAsync();
                }
            }
        }
    }
}
