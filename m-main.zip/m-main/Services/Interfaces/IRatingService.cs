﻿using Movie_Catalog.Data.Models;

namespace Movie_Catalog.Services.Interfaces
{
    public interface IRatingService
    {
        Task<IEnumerable<Rating>> GetAllRatingsAsync();

        Task<Rating?> GetRatingByIdAsync(int id);

        // ✅ UPDATED: Now takes movie title instead of ID
        Task AddRatingAsync(string title, double ratingValue);

        Task DeleteRatingAsync(int id);

        Task<IEnumerable<Rating>> GetRatingsByMovieIdAsync(int movieId);
    }
}
