﻿using Movie_Catalog.Data.Models;
using System.Threading.Tasks;

namespace Movie_Catalog.Services.Interfaces
{
    public interface IDirectorService
    {
        Task<ICollection<Director>> GetAllDirectorsAsync();

        Task<Director> GetDirectorByIdAsync(int id);

        Task<Director> GetDirectorByNameAsync(string name); // New method to get director by name

        Task AddDirectorAsync(string name);  // New method to add a new director

        Task EditAsync(int id, string name);
    }
}
