﻿using Microsoft.EntityFrameworkCore;
using Movie_Catalog.Data.Models;
using Movie_Catalog.Services.Interfaces;

namespace Movie_Catalog.Services
{
    public class MovieService : IMovieService
    {
        private readonly MovieCatalogContext _context;

        public MovieService(MovieCatalogContext context)
        {
            _context = context;
        }

        public async Task<ICollection<Movie>> GetAllMoviesAsync()
        {
            return await _context.Movies
                .Include(m => m.Genre)
                .Include(m => m.Director)
                .ToListAsync();
        }

        public async Task<Movie> GetMovieByIdAsync(int id)
        {
            var movie = await _context.Movies
                .Include(m => m.Genre)
                .Include(m => m.Director)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (movie == null)
            {
                throw new KeyNotFoundException($"Movie with id {id} was not found.");
            }

            return movie;
        }


        public async Task CreateAsync(string title, string? description, int? releaseYear, int? genreId, int? directorId, double rating)
        {
            var movie = new Movie
            {
                Title = title,
                Description = description,
                ReleaseYear = releaseYear,
                GenreId = genreId,
                DirectorId = directorId,
                Rating = rating
            };

            await _context.Movies.AddAsync(movie);
            await _context.SaveChangesAsync();
        }

        public async Task EditAsync(int id, string title, string? description, int? releaseYear, int? genreId, int? directorId, double rating)
        {
            var movie = await GetMovieByIdAsync(id);

            movie.Title = title;
            movie.Description = description;
            movie.ReleaseYear = releaseYear;
            movie.GenreId = genreId;
            movie.DirectorId = directorId;
            movie.Rating = rating;

            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var movie = await _context.Movies
                .Include(m => m.Ratings) // Include ratings to handle the foreign key constraint
                .FirstOrDefaultAsync(m => m.Id == id);

            if (movie == null)
            {
                throw new KeyNotFoundException($"Movie with id {id} was not found.");
            }

            // Remove the related ratings first
            _context.Ratings.RemoveRange(movie.Ratings);

            // Now remove the movie
            _context.Movies.Remove(movie);

            await _context.SaveChangesAsync();
        }


    }
}
