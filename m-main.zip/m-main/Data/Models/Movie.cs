﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Movie_Catalog.Data.Models
{
    [Table("movies")]
    public class Movie
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        // Title is required and cannot be null
        [Required]
        [Column("title")]
        public string Title { get; set; }

        // Description is optional and can be null
        [Column("description")]
        public string? Description { get; set; }

        // Release year is optional and can be null
        [Column("release_year")]
        public int? ReleaseYear { get; set; }

        // Genre is optional, can be null, and is linked to Genre table
        [ForeignKey("Genre")]
        [Column("genre_id")]
        public int? GenreId { get; set; }

        public Genre? Genre { get; set; }

        // Director is optional, can be null, and is linked to Director table
        [ForeignKey("Director")]
        [Column("director_id")]
        public int? DirectorId { get; set; }

        public Director? Director { get; set; }

        // Ratings collection is optional and can be null (movie may not have ratings)
        public ICollection<Rating>? Ratings { get; set; }

        // Rating is optional and can be null (not every movie may have a rating)
        [Column("rating")]
        public double? Rating { get; set; }
    }
}
