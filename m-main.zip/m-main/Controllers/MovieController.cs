﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Movie_Catalog.Data.Models;
using Movie_Catalog.Models;
using Movie_Catalog.Services;
using Movie_Catalog.Services.Interfaces;

namespace Movie_Catalog.Controllers
{
    public class MovieController : Controller
    {
        private readonly ILogger<MovieController> _logger;
        private readonly IMovieService _movieService;
        private readonly IGenreService _genreService;
        private readonly IDirectorService _directorService;

        public MovieController(
            ILogger<MovieController> logger,
            IMovieService movieService,
            IGenreService genreService,
            IDirectorService directorService)
        {
            _logger = logger;
            _movieService = movieService;
            _genreService = genreService;
            _directorService = directorService;
        }

        [HttpGet("/")]
        public async Task<IActionResult> All()
        {
            try
            {
                var movies = await _movieService.GetAllMoviesAsync();
                return View(movies);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching all movies.");
                return View("Error", new ErrorViewModel { Message = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            try
            {
                var genres = await _genreService.GetAllGenresAsync();
                var directors = await _directorService.GetAllDirectorsAsync();

                ViewBag.Genres = new SelectList(genres, "Id", "Name");
                return View();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading Create view.");
                return View("Error", new ErrorViewModel { Message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create(string title, string description, int? releaseYear, int? genreId, string directorName, double rating)
        {
            try
            {
                // Check if the director already exists by name
                var director = await _directorService.GetDirectorByNameAsync(directorName);

                if (director == null)
                {
                    // If the director does not exist, create a new one
                    await _directorService.AddDirectorAsync(directorName);
                    director = await _directorService.GetDirectorByNameAsync(directorName);  // Re-fetch the newly added director
                }

                // Create the movie using the director's ID
                await _movieService.CreateAsync(title, description, releaseYear, genreId, director.Id, rating);
                return RedirectToAction("All");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating movie.");
                return View("Error", new ErrorViewModel { Message = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            try
            {
                var movie = await _movieService.GetMovieByIdAsync(id);

                // Check if the movie is found
                if (movie == null)
                {
                    // Return a "Not Found" response if movie doesn't exist
                    return NotFound();
                }

                // Get all genres and directors for the dropdown lists
                var genres = await _genreService.GetAllGenresAsync();
                var directors = await _directorService.GetAllDirectorsAsync();

                // Populate ViewBag for genres and directors dropdowns
                ViewBag.Genres = new SelectList(genres, "Id", "Name", movie.GenreId);
                ViewBag.Directors = new SelectList(directors, "Id", "FullName", movie.DirectorId);

                // Pass the movie model to the view for editing
                return View(movie);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error loading movie with ID {id} for editing.");
                return View("Error", new ErrorViewModel { Message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Movie movie)
        {
            try
            {
                await _movieService.EditAsync(movie.Id, movie.Title, movie.Description, movie.ReleaseYear, movie.GenreId, movie.DirectorId, (double)movie.Rating);
                return RedirectToAction("All");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error editing movie.");
                return View("Error", new ErrorViewModel { Message = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _movieService.DeleteAsync(id);
                return RedirectToAction("All");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting movie with ID {id}.");
                return View("Error", new ErrorViewModel { Message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                await _movieService.DeleteAsync(id);
                return RedirectToAction("All");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error confirming deletion of movie with ID {id}.");
                return View("Error", new ErrorViewModel { Message = ex.Message });
            }
        }
    }
}
